package gr.anifora.cycling

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import com.google.android.gms.location.LocationServices
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var startField: EditText
    private lateinit var endField: EditText
    private var routeOverlay: Polyline? = null
    private var selectedRoute: List<GeoPoint> = emptyList()
    private var selectedAscent = 0.0
    private var selectedDistance = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        buildScreen()
        requestLocationPermission()
        showCurrentLocation()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 10)
            setBackgroundColor(0xFF101A17.toInt())
        }
        val title = TextView(this).apply {
            text = "ΑΝΑΒΑΣΗ  🚴"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 0, 0, 10)
        }
        outer.addView(title)
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startField = EditText(this).apply {
            hint = "Αφετηρία: πλάτος,μήκος"
            setSingleLine()
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB7C7C0.toInt())
        }
        endField = EditText(this).apply {
            hint = "Προορισμός: πλάτος,μήκος"
            setSingleLine()
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB7C7C0.toInt())
        }
        fields.addView(startField, LinearLayout.LayoutParams(0, 54, 1f))
        fields.addView(endField, LinearLayout.LayoutParams(0, 54, 1f))
        outer.addView(fields)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val plan = Button(this).apply {
            text = "Σχεδίαση"
            setOnClickListener { planRoute() }
        }
        val record = Button(this).apply {
            text = "● Καταγραφή"
            setOnClickListener { toggleRecording() }
        }
        actions.addView(plan, LinearLayout.LayoutParams(0, 52, 1f))
        actions.addView(record, LinearLayout.LayoutParams(0, 52, 1f))
        outer.addView(actions)
        status = TextView(this).apply {
            text = "Έτοιμο. Δώσε συντεταγμένες ή πάρε την τρέχουσα θέση σου."
            textSize = 13f
            setTextColor(0xFFE7F0EB.toInt())
            setPadding(0, 8, 0, 6)
        }
        outer.addView(status)
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(13.5)
            controller.setCenter(GeoPoint(40.6401, 22.9444)) // default map centre: Thessaloniki
        }
        outer.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        stats = TextView(this).apply {
            text = "Απόσταση: —   Ανάβαση: —   Μέγιστη κλίση: —"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 4)
        }
        outer.addView(stats)
        val hint = TextView(this).apply {
            text = "MVP 0.1 • Οι διαδρομές υπολογίζονται από BRouter. Έλεγχε πάντα την ασφάλεια της πορείας."
            textSize = 10f
            setTextColor(0xFF9FB2A9.toInt())
        }
        outer.addView(hint)
        setContentView(outer)
    }

    private fun requestLocationPermission() {
        val perms = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (perms.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms, 100)
        }
    }

    private fun showCurrentLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                val p = GeoPoint(loc.latitude, loc.longitude)
                map.controller.animateTo(p)
                startField.setText("%.6f,%.6f".format(loc.latitude, loc.longitude))
            }
        }
    }

    private fun toggleRecording() {
        val intent = Intent(this, RideTrackingService::class.java)
        if (RideTrackingService.running) {
            stopService(intent)
            status.text = "Η καταγραφή σταμάτησε."
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestLocationPermission()
                status.text = "Χρειάζεται άδεια ακριβούς τοποθεσίας."
                return
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "Η καταγραφή ξεκίνησε. Μπορείς να αφήσεις την οθόνη κλειστή."
        }
    }

    private fun parsePoint(text: String): GeoPoint? = try {
        val parts = text.trim().split(",")
        GeoPoint(parts[0].toDouble(), parts[1].toDouble())
    } catch (_: Exception) { null }

    private fun planRoute() {
        val from = parsePoint(startField.text.toString())
        val to = parsePoint(endField.text.toString())
        if (from == null || to == null) {
            status.text = "Βάλε συντεταγμένες ως πλάτος,μήκος (π.χ. 40.6401,22.9444). Η αναζήτηση διευθύνσεων θα προστεθεί."
            return
        }
        status.text = "Υπολογίζω ποδηλατικές εναλλακτικές…"
        thread {
            try {
                val candidates = (0..3).mapNotNull { idx -> requestRoute(from, to, idx) }
                if (candidates.isEmpty()) throw Exception("Δεν βρέθηκε διαδρομή. Δοκίμασε ξανά αργότερα.")
                // Prefer lower total ascent, with a modest distance penalty to avoid absurd detours.
                val best = candidates.minByOrNull { it.ascent + max(0.0, it.distanceKm - candidates.minOf { c -> c.distanceKm }) * 18.0 }!!
                runOnUiThread {
                    selectedRoute = best.points
                    selectedAscent = best.ascent
                    selectedDistance = best.distanceKm
                    routeOverlay?.let { map.overlays.remove(it) }
                    routeOverlay = Polyline().apply {
                        setPoints(best.points)
                        outlinePaint.strokeWidth = 9f
                        outlinePaint.color = 0xFF18B889.toInt()
                    }
                    map.overlays.add(routeOverlay)
                    map.zoomToBoundingBox(routeOverlay!!.boundingBox, true, 70)
                    stats.text = "Απόσταση: %.1f km   Ανάβαση: +%.0f m   Μέγιστη κλίση: %.1f%%".format(best.distanceKm, best.ascent, best.maxGrade)
                    status.text = "Βρέθηκαν ${candidates.size} επιλογές. Εμφανίζεται η πιο ήπια με βάση απόσταση και ανάβαση."
                    map.invalidate()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.message ?: "Σφάλμα υπολογισμού διαδρομής." }
            }
        }
    }

    private data class Route(val points: List<GeoPoint>, val ascent: Double, val distanceKm: Double, val maxGrade: Double)

    private fun requestRoute(a: GeoPoint, b: GeoPoint, alternative: Int): Route? {
        val params = "lonlats=${a.longitude},${a.latitude}|${b.longitude},${b.latitude}" +
                "&profile=trekking&alternativeidx=$alternative&format=geojson"
        val conn = (URL("https://brouter.de/brouter?$params").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            requestMethod = "GET"
        }
        try {
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val coords = root.getJSONArray("features").getJSONObject(0)
                .getJSONObject("geometry").getJSONArray("coordinates")
            val pts = mutableListOf<GeoPoint>()
            var ascent = 0.0
            var distance = 0.0
            var maxGrade = 0.0
            var prev: DoubleArray? = null
            for (i in 0 until coords.length()) {
                val c = coords.getJSONArray(i)
                val lon = c.getDouble(0); val lat = c.getDouble(1)
                val ele = if (c.length() > 2 && !c.isNull(2)) c.getDouble(2) else Double.NaN
                pts.add(GeoPoint(lat, lon))
                val p = prev
                if (p != null) {
                    val d = haversine(p[0], p[1], lon, lat)
                    distance += d
                    if (!ele.isNaN() && !p[2].isNaN()) {
                        val rise = ele - p[2]
                        if (rise > 0) ascent += rise
                        if (d > 1.0) maxGrade = max(maxGrade, abs(rise / d * 100.0))
                    }
                }
                prev = doubleArrayOf(lon, lat, ele)
            }
            if (pts.size < 2) return null
            return Route(pts, ascent, distance / 1000.0, maxGrade)
        } finally { conn.disconnect() }
    }

    private fun haversine(lon1: Double, lat1: Double, lon2: Double, lat2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val x = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(x))
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { map.onPause(); super.onPause() }
}
