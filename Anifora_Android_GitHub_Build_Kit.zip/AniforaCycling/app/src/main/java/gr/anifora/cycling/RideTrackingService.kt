package gr.anifora.cycling

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import android.os.Looper

class RideTrackingService : Service() {
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var callback: LocationCallback

    override fun onCreate() {
        super.onCreate()
        running = true
        val channelId = "ride_tracking"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Καταγραφή ποδηλασίας", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("Ανάβαση – καταγραφή ενεργή")
                .setContentText("Καταγράφεται η ποδηλατική σου διαδρομή")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Ανάβαση – καταγραφή ενεργή")
                .setContentText("Καταγράφεται η ποδηλατική σου διαδρομή")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
        startForeground(7, notification)
        fused = LocationServices.getFusedLocationProviderClient(this)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateDistanceMeters(5f)
            .build()
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val prefs = getSharedPreferences("ride", MODE_PRIVATE)
                val old = prefs.getString("last_point", "")
                prefs.edit().putString("last_point", "${loc.latitude},${loc.longitude},${loc.altitude},${loc.time}").apply()
                prefs.edit().putLong("last_update", loc.time).apply()
            }
        }
        try { fused.requestLocationUpdates(request, callback, Looper.getMainLooper()) }
        catch (_: SecurityException) { stopSelf() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        if (::fused.isInitialized && ::callback.isInitialized) fused.removeLocationUpdates(callback)
        running = false
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object { @Volatile var running: Boolean = false }
}
